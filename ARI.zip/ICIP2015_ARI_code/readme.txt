This package includes the implementation of
 'Adaptive Residual Interpolation for Color Image Demosaicking'. 

This code is available only for reserch purpose.
If you use this code for future publications,
please cite the following paper.

Yusuke Monno, Daisuke Kiku, Masayuki Tanaka, and Masatoshi Okutomi,
'Adaptive Residual Interpolation for Color Image Demosaicking',
IEEE International Conference on Image Processing, 2015.

Demo script
  run_demo.m

---------------------------------------------------------------------------

Project page
    http://www.ok.ctrl.titech.ac.jp/res/DM/RI.html

Copyright (C) 2015 Yusuke Monno and Daisuke Kiku. All rights reserved.
ymonno@ok.ctrl.titech.ac.jp
http://www.ok.ctrl.titech.ac.jp/~ymonno/

September 25, 2015.
